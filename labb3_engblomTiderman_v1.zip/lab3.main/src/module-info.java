/**
 * 
 */
/**
 * @author John Engblom Sandin 
 *
 */
module lab3 {
	requires se.hig.aod.lab3;
	requires org.junit.jupiter.api;
}